<?php
if(!defined('INITIALIZED'))
	exit;

echo '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
$password = trim($_REQUEST['password']);
if(empty($password))
{
	echo 'xxx';
	exit;
}
if(strlen($password) > 7 && strlen($password) < 30)
{
	if (!preg_match("#.*^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).*$#", $password))
		echo 'xxx';
	else
		echo 'ok';
}
else
	echo 'xxx';
exit;