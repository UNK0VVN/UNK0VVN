<?php
$main_content .= 'Your code here.';
?>