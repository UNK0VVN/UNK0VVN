<?php  
$main_content .= '

<center> <font color="red" size="4"> ~~Ganja System~~   </center> </font> <br><br>
<font size="3"><u>Ganja System po spaleniu:</u></font> <br><br>

<font color="blue" size="2">1 raz - Daje 5 lvli, oraz wysyła do specjalnego roomu gdzie
 są specjalne potwory dające więcej exp oraz złota!
 leci o 70% szybciej!<br><br>
 
 
2 raz -  Daje 2 m lvl oraz wysyła Cie do Tp roomu z 50% szybszym exp!<br><br>

3 raz - Daje Ci 300 many oraz 30% szybszy exp w Tp Roomie!<br><br>

4 raz - 20% Szybszy exp w Tp Roomie oraz stajesz się zawodowym jaraczem ! ;) <br><br>

5 i kolejny raz - 10% Szybszy exp w Tp Roomie ;)<br><br></font>

<center>
<img src="http://img220.imageshack.us/img220/4164/ganja2.png"</img>
<img src="http://img59.imageshack.us/img59/6272/ganja3g.png"</img>
<img src="http://img716.imageshack.us/img716/126/ganja4.png"</img>
<img src="http://img685.imageshack.us/img685/967/fajka4.png"</img>
<img src="http://img109.imageshack.us/img109/8453/ganja5.png"</img>
<img src="http://img94.imageshack.us/img94/9335/ganjasys.png"</img><br>
</center>
';  
?>