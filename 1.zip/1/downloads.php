<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /> 
<?PHP
$main_content .= ' 
<center>
<table border="1">
<tbody><tr><td><table width="500" border="0" cellpadding="4" cellspacing="1">
  <tbody>
    <tr>
      <td colspan="2" bgcolor="#505050"><b><font color="#505050">..</font><font color="WHITE">Downloads!</font></b></td>  
 </tr>
    <tr bgcolor="#d4c0a1">
      <td colspan="2">PentiumOts Client!</td>
    </tr>
    <tr bgcolor="#f1e0c6">
      <td width="80" align="center"><img src="http://1.bp.blogspot.com/_XyYbN_2bWn8/SfErD-MadjI/AAAAAAAABBM/HNi7D04VScw/S220/TibiaIcon.png" alt="" /><br />
        </td>
      <td>
Nasz Wlasny Klient <a href="http://tibiaclient.com/files/tibia854.exe">Download!</a>
        </td>
    <tr>
      <td colspan="2" bgcolor="#505050"><b><font color="#505050">..</font><font color="WHITE">Dobre Rozmowy!</font></b></td>
    </tr>
    <tr bgcolor="#d4c0a1">
    </tr>
    <tr bgcolor="#f1e0c6">
      <td width="80" align="center"><img src="http://img94.imageshack.us/img94/1526/7510daxriderteamspeak2r.jpg" alt="" /><br />
        </td>
      <td>
Team Speak 2 <a href="ftp://ftp.freenet.de/pub/4players/teamspeak.org/releases/ts2_client_rc2_2032.exe">Download!</a>
    </tr>
  </tbody>
</table>
      </td>
</tr></tbody></table>
</center>';
?>