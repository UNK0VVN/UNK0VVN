<?php  
$main_content .= '  
<style>  
.KL{background-color:none;}  
.KL:hover{background-color:white;font-weight:bold;color:black;}  
</style>  
<hr/>  
<center><b>BONUSY DZIALAJA GDY MASZ FULL OUTFIT !<br>
MARIA OTS ADDON BONUSES !</b></center>  
<hr/>  


<TABLE table  BGCOLOR="'.$config['site']['darkborder'].'" BORDER=0 CELLPADDING=4 CELLSPACING=1 WIDTH=100%>  
<TR BGCOLOR="'.$config['site']['vdarkborder'].'" ><TD CLASS=white COLSPAN=5><B>Addon Bonus Table</B></TD></TR>  
<TR><TD><TABLE BORDER=0 CELLPADDING=2 CELLSPACING=1 WIDTH=100%>  
<TR BGCOLOR=#eeddb9><TD><B>Outfit</B></TD><TD><B>Bonus</B></TD></TR>  

<TR class="KL" BGCOLOR=#eeddb9><TD><center><b>Citizen</b><br>  
<img src="./images/addons/1028.gif"/>&nbsp</center><br></TD><TD>+ 5 speed, + 100 hp</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Hunter</b><br>  
<img src="./images/addons/1029.gif"/>&nbsp</center><br></TD><TD>+5 distance skill</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Mage</b><br>  
<img src="./images/addons/1030.gif"/>&nbsp</center><br></TD><TD>+1 magic level, +200 mana</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Knight</b><br>  
<img src="./images/addons/1039.gif"/>&nbsp</center><br></TD><TD>+3 sword, axe, club, fist skill</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Nobleman/Noblewoman</b><br>  
<img src="./images/addons/1032.gif"/>&nbsp</center><br></TD><TD>+5 club, fist skill</TD></TR>   
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Warrior</b><br>  
<img src="./images/addons/1034.gif"/>&nbsp</center><br></TD><TD>+5 sword</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Barbarian</b><br>  
<img src="./images/addons/1047.gif"/>&nbsp</center><br></TD><TD>+5 axe</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Wizzard</b><br>  
<img src="./images/addons/1045.gif"/>&nbsp</center><br></TD><TD>+2 magic level, +100 mana</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Druid</b><br>  
<img src="./images/addons/1044.gif"/>&nbsp</center><br></TD><TD>+1 magic level, <b>Mana Shield</b>, +100hp/5sec</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Oriental</b><br>  
<img src="./images/addons/1046.gif"/>&nbsp</center><br></TD><TD>+200 mana, +200 health, +10 speed</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Pirate</b><br>  
<img src="./images/addons/1051.gif"/>&nbsp</center><br></TD><TD>+3 sword, + 200 health, Drunk & Drown Resistant</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Assasin</b><br>  
<img src="./images/addons/1052.gif"/></center><br></TD><TD>+20 speed, + 2 distance fighting</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Beggar</b><br>  
<img src="./images/addons/1053.gif"/>&nbsp</center><br></TD><TD>+200 health</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Shaman</b><br>  
<img src="./images/addons/1054.gif"/>&nbsp</center><br></TD><TD>+2 magic level</TD></TR>  
<TR  class="KL"  BGCOLOR=#eeddb9><TD><center><b>Norseman/Norsewoman</b><br>  
<img src="./images/addons/1151.gif"/>&nbsp</center><br></TD><TD>+2 shielding, +200 health, Reflect 20% Ice Damage</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Nightmare</b><br>  
<img src="./images/addons/1168.gif"/>&nbsp</center><br></TD><TD>+5 shielding</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Brotherhood</b><br>  
<img src="./images/addons/1178.gif"/>&nbsp</center><br></TD><TD>+2 magic level, , +100 health</TD></TR>  
<TR  class="KL" BGCOLOR=#eeddb9><TD><center><b>Yalahari</b><br>  
<img src="./images/addons/924.gif"/></center><br></TD><TD>+2 magic level, +5 Speed</TD></TR>  
</TABLE></TD></TR>  
</TABLE>';  
?>