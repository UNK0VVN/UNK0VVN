<?PHP
$main_content .= 'Edit this in <b>vantagens.php</b>.';
?>
