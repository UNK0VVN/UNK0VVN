##### CREDITS #####
Version 0.3.6 r.70
Acc. script:
*Gesior - e-mail: jerzyskalski@wp.pl
*widnet - e-mail: loleslav.pl@gmail.com
*Norix - e-mail: norix92@hotmail.de
*Cybermaster - e-mail: cybermaster2008@hotmail.com
*zakius - e-mail: zakius.rolkash@gmail.com
POT:
*Wrzasq - user from www.otfans.net
Layouts:
*CipSoft Gmbh - www.tibia.com
Monsters images:
*Unknown author
Items images:
*Unknown author
