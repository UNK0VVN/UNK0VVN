<?PHP
$main_content .= '<center><b><h2>'.$config['server']['serverName'].' Gallery</h2></b><br />
<embed
src="gallery/imagerotator.swf"
width="640"
height="480"
allowscriptaccess="always"
allowfullscreen="true"
flashvars="width=651&height=489&file=gallery/images/imageslist.xml" /></center>';
?>