<?PHP
                $main_content .= '<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=100%><TR BGCOLOR="'.$config['site']['vdarkborder'].'">
	<TD CLASS=white><b><center>Commands</center><b></TD>
	</TR><TR BGCOLOR='.$config['site']['darkborder'].'>
	</TD></TABLE>';
	                $bgcolor = $config['site']['lightborder'];
					$bgcolor2 = $config['site']['darkborder'];
					
					    $main_content .= '<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=4 WIDTH=100%><TR BGCOLOR="'.$config['site']['vdarkborder'].'">
	</TR><TR BGCOLOR='.$config['site']['darkborder'].'>
	
	<TD>
	<P ALIGN=CENTER>
        <table bordercolor="brown" bodercolorlight="brown" bordercolordark="brown" border="10"><tr bordercolor="red" bodercolorlight="red" bordercolordark="red" border="1"><td border="1"><h3><center>Commands For Houses:</center></h3>
<ul><li><b>!buyhouse</b> - Buy house (75 lvl),</li>
<li><b>!sellhouse </b>- Sell your house,</li>
<li><b>!leavehouse</b> - Leave your house,</li><br>
<li><b>aleta grav </b>- House door list,</li>
<li><b>aleta som</b> - Edit subowners list,</li>
<li><b>aleta sio</b> - Edit guest list,</li><br>
<li><b>alana sio "nick</b> - Kick player from house.</li>
	</TR></TD></TABLE><br/>		
<table bordercolor="brown" bodercolorlight="brown" bordercolordark="brown" border="10"><tr bordercolor="red" bodercolorlight="red" bordercolordark="red" border="1"><td border="1"><h3><center>Commands For Sell Vials and Pearls:</center></h3>
<li><b>!sell vials</b> - Sell your empty vials.</li>
<li><b>!sell pearls</b> - Sell your all pearls,</li>
	</TR></TD></TABLE><br/></ul>
			
<table bordercolor="brown" bodercolorlight="brown" bordercolordark="brown" border="10"><tr bordercolor="red" bodercolorlight="red" bordercolordark="red" border="1"><td border="1"><h3><center>Other Commands:</center></h3>
<ul>
<li><b>!frags </b> - Your last frags & total frags,</li>
<li><b>!online </b> - List of players who are online,</li>
<li><b>!uptime </b> - Server Uptime,</li>
<li><b>!serverinfo </b> - Informations about Maria OTS,</li>
<li><b>!bless </b> - Buy all blessings,</li>
<li><b>!aol </b> - Buy amulet of loss,</li>
<li><b>!color </b> - Changing players outfit in party,</li>
<li><b>!go </b> - Changing players outfit in guild,</li>
<li><b>/bg text </b> - Guild Broadcast - only rank above or equal Vice-Leader,</li>
<li><b>/commands </b> - Show avaiable commands,</li>
<li><b>!addon [addon name]</b> - Command to Addon Doll,</li>
<li><b>!outfit [outfit name]</b> - Command to Outfit Doll,</li>
<li><b>!hunt</b> - Command to Bounty Hunters,</li>
<li><b>!deathlist [player name] </b> - Player Deaths List.</li>

	</TR></TD></TABLE><br/></ul></td></tr></table>	        </ul></td></tr></table>

	        </ul></td></tr></table>
    </FONT>		
	</P>';
?>
