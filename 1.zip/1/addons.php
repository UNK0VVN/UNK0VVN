<?PHP
$main_content .= '
<center><font size="4">Citizen Outfit</font></center><br />
<b>Backpack addon</b> (First citizen addon)<br />
<img src="./images/addons/Male_Citizen_1.gif"/>
<img src="./images/addons/Female_Citizen_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>100 Minotaur Leathers</li>
</ul><br />


<b>Hat addon</b> (Second citizen addon)<br />
<img src="./images/addons/Male_Citizen_2.gif"/>
<img src="./images/addons/Female_Citizen_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>100 Chicken Feathers</li>
<li>50 Honeycombs</li>
<li>Legion Helmet</li>
</ul><br /><br />

<center><font size="4">Hunter Outfit</font></center><br />

<b>Cloak addon</b> (First hunter addon)<br />
<img src="./images/addons/Male_Hunter_1.gif"/>
<img src="./images/addons/Female_Hunter_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>Royal Steel</li>
<li>Hell steel</li>

<li>Draconian Steel</li>
<li>100 Red Dragon Leathers</li>
<li>100 Lizard Leathers</li>
<li>5 enchanted chicken wings</li>
<li>engraved crossbow</li>
</ul><br/>

<b>Gloves addon</b> (Second hunter addon)<br />
<img src="./images/addons/Male_Hunter_2.gif"/>


<img src="./images/addons/Female_Hunter_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>Sniper Gloves</li>
</ul><br /><br />

<center><font size="4">Mage Outfit</font></center><br />
<b>Ferumbras Hat addon</b><br />
<img src="./images/addons/Male_Mage_2.gif"/>
<img src="./images/addons/Female_Summoner_2.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>Ferumbras Hat</li>
</ul><br />

<b>Wand addon</b><br />
<img src="./images/addons/Male_Mage_1.gif"/>
<img src="./images/addons/Female_Summoner_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>20 Ankhs</li>
<li>Soul Stone</li>

<li>10 magic sulphors</li>
<li>All wands & rods</li>

</ul><br /><br />

<center><font size="4">Knight Outfit</font></center><br />
<b>Sword addon</b><br />
<img src="./images/addons/Male_Knight_1.gif"/>
<img src="./images/addons/Female_Knight_1.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>Chunk of Crude Iron</li>
<li>100 Iron Ores</li>
</ul><br />

<b>Helmet addon</b><br />
<img src="./images/addons/Male_Knight_2.gif"/>
<img src="./images/addons/Female_Knight_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>100 Behemoth Fangs</li>

<li>Damaged Steel Helmets</li>
<li>Warrior Sweat</li>
<li>Royal Steel</li>
</ul><br /><br />
<center><font size="4">Wizard Outfit</font></center><br />
<b>Skull addon</b><br />

<img src="./images/addons/Male_Wizard_2.gif"/>
<img src="./images/addons/Female_Wizard_2.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>medusa shield</li>
<li>dragon scale mail</li>
<li>crown legs</li>
<li>ring of the sky</li>
</ul><br />

<b>Greaves addon</b><br />
<img src="./images/addons/Male_Wizard_1.gif"/>
<img src="./images/addons/Female_Wizard_1.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>50 holy orchids</li>
</ul><br /><br />

<center><font size="4">Summoner Outfit</font></center><br />
<b>Robe addon</b><br />
<img src="./images/addons/Male_Summoner_2.gif"/>
<img src="./images/addons/Female_Mage_2.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>70 bat wings</li>

<li>20 red pieces of cloth</li>
<li>40 ape fur</li>
<li>35 holy orchid</li>
<li>10 spools of spider silk yarn</li>
<li>60 lizard scales</li>
<li>40 red dragon scales</li>
<li>15 magic sulphurs</li>
<li>30 vampire dusts</li>
</ul><br />

<b>Vial Belt addon</b><br />
<img src="./images/addons/Male_Summoner_1.gif"/>
<img src="./images/addons/Female_Mage_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>Winning Lottery Ticket</li>
</ul><br /><br />
<center><font size="4">Druid Outfit</font></center><br />
<b>Animal Skin addon</b><br />
<img src="./images/addons/Male_Druid_2.gif"/>

<img src="./images/addons/Female_Druid_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>60 Green Pieces of Cloth</li>
<li>100 Demon Dusts</li>

</ul><br />

<b>Bear Paws addon</b><br />
<img src="./images/addons/Male_Druid_1.gif"/>
<img src="./images/addons/Female_Druid_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>50 Bear Paws</li>
<li>50 Wolf Paws</li>
</ul><br /><br />
<center><font size="4">Oriental Outfit</font></center><br />

<b>Sabre addon</b><br />
<img src="./images/addons/Male_Oriental_1.gif"/>
<img src="./images/addons/Female_Oriental_1.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>Mermaid Comb</li>
</ul><br />

<b>Turban addon</b><br />
<img src="./images/addons/Male_Oriental_2.gif"/>

<img src="./images/addons/Female_Oriental_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>100 Ape Furs</li>
<li>100 fish fins</li>

<li>100 Blue Pieces of Cloth</li>
<li>2 Enchanted Chicken Wings</li>
</ul><br /><br />
<center><font size="4">Pirate Outfit</font></center><br />
<b>Sabre addon</b><br />
<img src="./images/addons/Male_Pirate_1.gif"/>
<img src="./images/addons/Female_Pirate_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>100 eye patches</li>

<li>100 peg legs</li>
<li>100 Hooks</li>
</ul><br />

<b>Pirate Hat addon</b><br />
<img src="./images/addons/Male_Pirate_2.gif"/>
<img src="./images/addons/Female_Pirate_2.gif"/><br /><br />

Ingredients:<br />
<ul>

<li>Ron the Ripper sabre</li>

<li>Deadeye Devious eye patch</li>
<li>Lethal Lissy shirt</li>
<li>Brutus Bloodbeard hat</li>
</ul><br /><br />
<center><font size="4">Assassin Outfit</font></center><br />
<b>Death Cloak addon</b> (First assassin addon)<br />
<img src="./images/addons/Male_Assassin_1.gif"/>
<img src="./images/addons/Female_Assassin_1.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>50 Blue Piece of Cloths</li>
<li>50 Green Piece of Cloths</li>
<li>50 Red Piece of Cloths</li>
<li>50 Brown Piece of Cloths</li>
<li>50 Yellow Piece of Cloths</li>
<li>50 White Piece of Cloths</li>
<li>10 Spider Silk Yarns = 100 Giant Spider Silks</li>
</ul><br />

<b>Sabre addon</b> (Second assassin addon)<br />
<img src="./images/addons/Male_Assassin_2.gif"/>
<img src="./images/addons/Female_Assassin_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>Nose Ring</li>
<li>1 Behemoth Claws</li>
</ul><br /><br />

<center><font size="4">Beggar Outfit</font></center><br />

<b>Beard addon</b> (First beggar addon)<br />
<img src="./images/addons/Male_Beggar_1.gif"/>
<img src="./images/addons/Female_Beggar_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>100 Ape Furs</li>
<li>2 Crystal Coins</li>
</ul><br />

<b>Staff addon</b> (Second beggar addon)<br />

<img src="./images/addons/Male_Beggar_2.gif"/>
<img src="./images/addons/Female_Beggar_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>50 Iron Ores</li>
<li>Simon the Beggar Favorite Staff</li>
</ul><br /><br />
<center><font size="4">Shaman Outfit</font></center><br />
<b>Voodoo Mask addon</b><br />
<img src="./images/addons/Male_Shaman_1.gif"/>

<img src="./images/addons/Female_Shaman_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>5 dworc vodoo dolls</li>
<li>mandrake</li>
</ul><br />

<b>Voodoo Staff addon</b><br />
<img src="./images/addons/Male_Shaman_2.gif"/>
<img src="./images/addons/Female_Shaman_2.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>5 banana staffs</li>
<li>5 tribal masks</li>
</ul><br /><br />
<center><font size="4">Warrior Outfit</font></center><br />
<b>Spiked Greaves addon</b> (First warrior addon)<br />
<img src="./images/addons/Male_Warrior_1.gif"/>
<img src="./images/addons/Female_Warrior_1.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>100 hardened bones</li>
<li>100 Turtle Shells</li>
<li>fighting spirit</li>
<li>dragon claw</li>
</ul><br />

<b>Sword on Back addon</b> (Second warrior addon)<br />
<img src="./images/addons/Male_Warrior_2.gif"/>
<img src="./images/addons/Female_Warrior_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>100 Iron Ores</li>
<li>royal steel</li>
</ul><br /><br />

<center><font size="4">Nobleman Outfit</font></center><br />
<b>Cloth addon</b><br />
<img src="./images/addons/Male_Nobleman_1.gif"/>
<img src="./images/addons/Female_Nobleman_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>15 Crystal Coins</li>
</ul><br />

<b>Top Hat addon</b><br />
<img src="./images/addons/Male_Nobleman_2.gif"/>

<img src="./images/addons/Female_Nobleman_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>15 Crystal Coins</li>

</ul><br /><br />
<center><font size="4">Barbarian Outfit</font></center><br />
<b>Barbarian Wig</b> (First barbarian addon)<br />
<img src="./images/addons/Male_Barbarian_2.gif"/>
<img src="./images/addons/Female_Barbarian_2.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>Fighting Spirit</li>
<li>Warrior Sweat</li>

<li>50 Pieces of Red Cloth</li>
<li>50 Pieces of Green Cloth</li>
<li>10 Spider Silk Yarn</li>
</ul><br />

<b>Axe</b> (Second barbarian addon)<br />
<img src="./images/addons/Male_Barbarian_1.gif"/>
<img src="./images/addons/Female_Barbarian_1.gif"/><br /><br />

Ingredients:<br />

<ul>
<li>100 Iron Ore</li>
<li>1 Huge Chunk of Crude Iron</li>
<li>50 Perfect Behemoth Fang</li>
<li>50 Lizard Leather</li>
</ul><br /><br />
<center><font size="4">Norseman Outfit</font></center><br />
<b>Spear addon</b><br />
<img src="./images/addons/Male_Norseman_1.gif"/>
<img src="./images/addons/Female_Norseman_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>5 Shards</li>

</ul><br />

<b>Hood/Earmuffs addon</b><br />
<img src="./images/addons/Male_Norseman_2.gif"/>
<img src="./images/addons/Female_Norseman_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>10 Shards</li>

</ul><br /><br />
<center><font size="4">Nightmare Outfit</font></center><br />

<b>Helmet addon</b><br />
<img src="./images/addons/Male_Nightmare_1.gif"/>
<img src="./images/addons/Female_Nightmare_1.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>Steel Helmet</li>
<li>100 Talons</li>
<li>150 Iron Ores</li>

<li>50 Green Pieces of Cloth</li>
<li>50 Red Pieces of Cloth}</li>
<li>500 Demonic Essences</li>
</ul><br />

<b>Lance and shield addon</b><br />
<img src="./images/addons/Male_Nightmare_2.gif"/>

<img src="./images/addons/Female_Nightmare_2.gif"/><br /><br />

Ingredients:<br />
<ul>
<li>Dragon Lance</li>

<li>Demon Shield</li>
<li>200 Talons</li>
<li>1500 Demonic Essences</li><br><br>
<center><font size="5" color="red">Premium Outfits</font></center><br />
<center><b>Preview: </b></center><br />
Cult: <img src="./images/outfits/1.jpg"/><br /><br>
Headsplitter: <img src="./images/outfits/2.jpg"/><br /><br>
Skullhunter: <img src="./images/outfits/3.jpg"/><br /><br>
Bloodwalker: <img src="./images/outfits/4.jpg"/><br /><br>
Brutetamer: <img src="./images/outfits/5.jpg"/>
<br /><br />

<font color="red"><b>Ingredients:</b></font><br />
<ul>
<li><a href="http://deltoria.pl/?subtopic=shopsystem">Premium Outfit Doll</a></li>';
?>