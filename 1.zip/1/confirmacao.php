<?PHP
$main_content .= 'Edit this in <b>confirmacao.php</b>.';
?>
